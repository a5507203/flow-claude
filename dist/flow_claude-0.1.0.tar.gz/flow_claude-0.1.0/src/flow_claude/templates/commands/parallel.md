python -m flow_claude.commands.set_parallel [number]
